num = ARGV[0].to_i
c = "123"
resultado = c.rjust(num, c)

print resultado


